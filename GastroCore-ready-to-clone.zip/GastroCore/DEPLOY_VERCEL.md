# 🚀 Desplegar GastroCore a Vercel

Esta guía te muestra cómo desplegar GastroCore en Vercel directamente desde GitHub.

---

## 📋 Requisitos

✅ Código en GitHub (público o privado)  
✅ Cuenta en Vercel (gratis en https://vercel.com)  
✅ Proyecto Supabase configurado  

---

## 🚀 Opción 1: Desde GitHub (Recomendado)

### 1️⃣ Pushear código a GitHub

```bash
cd GastroCore

# Si no tienes repo remoto:
git remote add origin https://github.com/tu-usuario/gastrocore.git
git branch -M main
git push -u origin main
```

### 2️⃣ Conectar a Vercel

1. Ir a https://vercel.com/new
2. Hacer clic en **"Continue with GitHub"**
3. Autorizar Vercel
4. Seleccionar repo **GastroCore**
5. En **Project Name** usar: `gastrocore`
6. En **Framework Preset** seleccionar: **Next.js**
7. En **Root Directory** dejar: `./` (raíz)

### 3️⃣ Agregar variables de entorno

En la página de Vercel, ir a **Environment Variables** y agregar:

```
NEXT_PUBLIC_SUPABASE_URL = https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 4️⃣ Desplegar

Hacer clic en botón azul **"Deploy"**

✅ ¡Listo en 1-2 minutos!

Tu app estará en: `https://gastrocore.vercel.app`

---

## 🚀 Opción 2: Desde CLI de Vercel

```bash
# 1. Instalar Vercel CLI
npm i -g vercel

# 2. Desde carpeta del proyecto
cd GastroCore

# 3. Loguear
vercel login

# 4. Desplegar
vercel

# 5. Seguir las preguntas interactivas
# - Vincular a cuenta de Vercel
# - Crear nuevo proyecto
# - Confirmar settings
```

---

## 🚀 Opción 3: Desde VS Code (Si tienes la extensión de Vercel)

1. Instalar extensión: **Vercel** (official)
2. Hacer clic en ícono de Vercel en sidebar
3. Seleccionar **"Deploy"**
4. Seguir pasos en la interfaz

---

## 🔐 Variables de Entorno en Vercel

### En Dashboard de Vercel:

1. Proyecto → **Settings**
2. **Environment Variables**
3. Agregar cada variable:

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
NODE_ENV=production
```

⚠️ **IMPORTANTE:**
- Nunca commitear `.env.local` con credenciales reales
- Las variables en Vercel son privadas y seguras
- Cada despliegue re-crea el contenedor con esas variables

---

## ✅ Verificar Despliegue

```bash
# Ver logs en tiempo real
vercel logs

# Ver estado del proyecto
vercel status

# Abrir en navegador
vercel --prod
```

---

## 🔄 Redeploy automático

Cada vez que hagas `git push` a la rama `main`, Vercel:
1. **Detecta** el cambio
2. **Compila** automáticamente
3. **Despliega** en segundos
4. ✅ El sitio se actualiza en vivo

---

## 🐛 Troubleshooting

### "Build failed"

```bash
# Revisar logs
vercel logs

# Soluciones comunes:
# 1. npm install no funcionó → verifica package.json
# 2. Variables de entorno faltando → agregar en Vercel Dashboard
# 3. TypeScript error → revisar console
```

### "404 en rutas"

- Vercel automáticamente reconoce Next.js App Router
- No hay que configurar nada especial
- Si persiste, revisar `next.config.mjs`

### "Base de datos no conecta"

- Verificar variables de Supabase en Vercel Dashboard
- Verificar que Supabase permite conexiones desde Vercel
- En Supabase: Settings → Database → Connection String

---

## 📊 Monitoreo

Vercel proporciona:

✅ **Analytics** — Visitors, Performance  
✅ **Function Logs** — Errores en API routes  
✅ **Deploy History** — Rollback a versión anterior  
✅ **Environment Variables** — Gestión centralizada  

Todo en: https://vercel.com/dashboard

---

## 💡 Pro Tips

### 1. Usar rama de staging

```bash
# Crear rama preview
git checkout -b staging

# Vercel crea automáticamente:
# https://gastrocore-staging.vercel.app
```

### 2. Dominio personalizado

En Vercel Dashboard:
- Project Settings → Domains
- Agregar tu dominio (ej: gastrocore.com)
- Seguir instrucciones de DNS

### 3. Rollback rápido

En Vercel Dashboard → Deployments:
- Ver historial de deploys
- Hacer clic en el anterior
- Botón "Promote to Production"

---

## 🔗 URLs importantes

| Recurso | Link |
|---------|------|
| **Vercel Dashboard** | https://vercel.com/dashboard |
| **Proyecto** | https://vercel.com/dashboard/gastrocore |
| **Docs de Vercel** | https://vercel.com/docs |
| **Docs de Next.js** | https://nextjs.org/docs |

---

## ✨ Próximos pasos

1. ✅ Código en GitHub
2. ✅ Conectado a Vercel
3. ✅ Variables de entorno configuradas
4. ✅ Desplegado y en vivo
5. 🎯 Acceder a: `https://tu-proyecto.vercel.app`
6. 🎯 Login con Supabase Auth

---

**¡Tu app está en producción! 🎉**
