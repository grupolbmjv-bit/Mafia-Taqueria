# ⚡ Deploy en Vercel — 5 minutos

Guía ULTRA RÁPIDA para desplegar GastroCore en Vercel.

---

## 🟢 OPCIÓN 1: Un click (Recomendado)

Si tienes el código en GitHub, simplemente:

### Paso 1: GitHub
```bash
git push origin main
```

### Paso 2: Vercel
1. Ir a https://vercel.com/new
2. Conectar GitHub account
3. Seleccionar repo **GastroCore**
4. Click en **Deploy**

✅ **¡LISTO!** En 2 minutos estará en vivo.

**Tu URL será:** `https://gastrocore.vercel.app` (o custom domain)

---

## 🟡 OPCIÓN 2: Extensión de Vercel en VS Code

```bash
# 1. Instalar extensión "Vercel" (oficial) en VS Code
# 2. Click en ícono de Vercel en sidebar
# 3. Click en "Deploy"
# 4. Confirmar opciones
```

✅ Listo en 1 click desde el editor.

---

## 🔴 OPCIÓN 3: Vercel CLI (Terminal)

```bash
# 1. Instalar
npm i -g vercel

# 2. Login
vercel login

# 3. Deploy
vercel --prod
```

Seguir preguntas interactivas. ✅ Listo en 2 minutos.

---

## 🔑 Variables de Entorno (IMPORTANTE)

### ANTES de hacer Deploy:

1. Ir a https://vercel.com/dashboard
2. Seleccionar proyecto **gastrocore**
3. Settings → **Environment Variables**
4. Agregar estas 3:

```
NEXT_PUBLIC_SUPABASE_URL
┗━ Valor: https://xxxxx.supabase.co

NEXT_PUBLIC_SUPABASE_ANON_KEY
┗━ Valor: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

SUPABASE_SERVICE_ROLE_KEY
┗━ Valor: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**DONDE OBTENER ESTOS VALORES:**

1. Supabase Dashboard
2. Settings → API
3. Copiar cada valor

---

## ✅ Checklist Rápido

- [ ] Código en GitHub
- [ ] Vercel account creada
- [ ] Variables de Supabase copiadas
- [ ] Deploy iniciado
- [ ] Variables agregadas en Vercel Dashboard
- [ ] Esperamos 2-3 minutos
- [ ] ✅ App en vivo!

---

## 🎯 Verificar Despliegue

```bash
# URL de tu app
https://gastrocore.vercel.app

# Dashboard de Vercel
https://vercel.com/dashboard/gastrocore

# Logs en tiempo real
vercel logs --follow
```

---

## 🔄 Updates Automáticos

Cada `git push` a `main`:
1. Vercel detecta cambio
2. Compila automáticamente
3. Despliega en segundos
4. Tu sitio se actualiza en vivo

**SIN HACER NADA MÁS.**

---

## 🆘 Si algo falla

### "Variables no están"
→ Ir a Vercel Dashboard → Settings → Environment Variables

### "Base de datos no conecta"
→ Verificar URLs de Supabase → Supabase es up?

### "Build error"
→ Logs en: `vercel logs --tail`

---

## 🎉 ¡LISTO!

Tu app está en producción:

```
🌐 https://gastrocore.vercel.app
📊 Dashboard: https://vercel.com/dashboard
🔐 Variables: ✅ Configuradas
🗄️ BD: ✅ Conectada a Supabase
🚀 Auto-deploy: ✅ Activo
```

**Felicidades! GastroCore está en vivo 🚀**
