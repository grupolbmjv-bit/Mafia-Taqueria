# 🚀 Instrucciones de Clonación — GastroCore

Este archivo contiene los pasos exactos para clonar y ejecutar GastroCore localmente.

---

## 📋 Requisitos

- **Git** instalado
- **Node.js 18+** (instalar desde https://nodejs.org)
- Cuenta en **Supabase** (gratis en https://supabase.com)

---

## ⚡ Paso 1: Clonar el repositorio

```bash
git clone https://github.com/TU_USUARIO/GastroCore.git
cd GastroCore
```

---

## 📦 Paso 2: Instalar dependencias

```bash
npm install
```

Esto instalará todas las librerías necesarias (Next.js, React, TailwindCSS, etc).

---

## 🔑 Paso 3: Configurar credenciales de Supabase

### 3a. Crear proyecto en Supabase

1. Ir a https://supabase.com
2. Hacer clic en **"New Project"**
3. Completar formulario:
   - Project name: `gastrocore-dev`
   - Database Password: Guardar en lugar seguro
   - Region: Seleccionar la más cercana
4. **Esperar 2-3 minutos** a que se cree

### 3b. Obtener credenciales

1. Abrir el proyecto creado
2. Ir a **Settings → API** (esquina inferior izquierda)
3. Copiar:
   - **Project URL** (Supabase URL)
   - **anon public** (Public key)
   - **service_role secret** (Private key)

### 3c. Crear archivo .env.local

```bash
cp .env.local.example .env.local
```

Abrir `.env.local` en tu editor favorito (VS Code, Sublime, etc) y reemplazar:

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 🗄️ Paso 4: Crear la base de datos

### Opción A: Desde Supabase Studio (más fácil) ✅

1. Abrir dashboard de Supabase
2. Ir a **SQL Editor**
3. Hacer clic en **"New Query"**
4. Copiar todo el contenido de: `supabase/migrations/0001_init.sql`
5. **Pegar en el editor**
6. Hacer clic en botón **▶️** (ejecutar)
7. ✅ ¡Listo! Las tablas se han creado

### Opción B: Desde Supabase CLI (avanzado)

```bash
npm install -g supabase
supabase link --project-ref tu-project-ref
supabase db push
```

---

## 👤 Paso 5: Crear primer usuario

### 5a. En Supabase Dashboard

1. Ir a **Authentication → Users**
2. Hacer clic en botón azul **"Add user"**
3. Llenar:
   - Email: `tu@email.com`
   - Password: `password123` (temporal)
4. Hacer clic en **"Create user"**

### 5b. Conectar usuario a la app

1. Ir a **SQL Editor** en Supabase
2. Crear nueva query
3. Ejecutar este código (reemplazar UUID):

```sql
-- Reemplazar 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' 
-- con el UUID del usuario que acabas de crear
-- (lo ves en Users → copiar el ID)

INSERT INTO organizaciones (nombre) 
VALUES ('Mi Restaurante');

INSERT INTO usuarios (
    id,
    organizacion_id,
    nombre_completo,
    rol_id,
    activo
) VALUES (
    'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',  -- ← Cambiar este UUID
    (SELECT id FROM organizaciones WHERE nombre = 'Mi Restaurante' LIMIT 1),
    'Tu Nombre',
    1,  -- Rol Administrador
    true
);
```

---

## ✅ Paso 6: Ejecutar la aplicación

```bash
npm run dev
```

Abrirá automáticamente en tu navegador:
```
http://localhost:3000
```

---

## 🔐 Paso 7: Loguearse

- **Email:** `tu@email.com`
- **Password:** `password123`

¡**¡LISTO!!** Verás el dashboard de GastroCore.

---

## 🛠️ Comandos útiles

```bash
# Desarrollo (hot reload)
npm run dev

# Build para producción
npm run build

# Ejecutar build previamente
npm start

# Linter
npm run lint
```

---

## ❓ ¿Algo no funciona?

1. **"Cannot find module"** → Ejecutar: `npm install`
2. **"env variables not found"** → Verificar que `.env.local` existe y tiene valores
3. **"Database connection error"** → Verificar que Supabase está activo
4. **"401 Unauthorized"** → Verificar que el usuario existe en auth + tabla usuarios

**Más ayuda:** Ver [`SETUP.md`](./SETUP.md)

---

## 📚 Documentación

- **Setup completo:** [`SETUP.md`](./SETUP.md)
- **Arquitectura:** [`arquitectura-erp-recetas.md`](./arquitectura-erp-recetas.md)
- **README:** [`README.md`](./README.md)

---

## 🎉 ¡Éxito!

Ya tienes GastroCore corriendo. Ahora puedes:

- ✅ Crear insumos
- ✅ Crear recetas
- ✅ Ver costeo automático
- ✅ Explorar el dashboard

**¡Bienvenido a GastroCore! 🍽️**
