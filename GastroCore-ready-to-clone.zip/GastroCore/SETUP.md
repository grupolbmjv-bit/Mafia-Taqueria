# 🍽️ GastroCore — Guía de Setup

Bienvenido a **GastroCore**, el ERP especializado en costeo de recetas para restaurantes. Esta guía te llevará paso a paso por la configuración inicial.

---

## 📋 Requisitos previos

- **Node.js 18+** y **npm** (o yarn/pnpm)
- **Git** configurado
- Cuenta en **[Supabase](https://supabase.com)** (gratis)
- **Git Bash** (recomendado en Windows, para consistencia)

---

## 🚀 Configuración rápida (5 minutos)

### 1️⃣ Clonar el repositorio

```bash
git clone https://github.com/tu-usuario/GastroCore.git
cd GastroCore
```

### 2️⃣ Instalar dependencias

```bash
npm install
```

### 3️⃣ Configurar Supabase

#### a) Crear proyecto en Supabase

1. Ir a [supabase.com](https://supabase.com)
2. Hacer clic en **"New Project"**
3. Completar:
   - **Name:** `gastrocore-dev` (o el que prefieras)
   - **Database Password:** Guardar en lugar seguro
   - **Region:** Seleccionar la más cercana a tu ubicación
4. Esperar a que se cree (2-3 minutos)

#### b) Obtener credenciales

1. Ir a **Settings → API** en el dashboard de Supabase
2. Copiar:
   - `Project URL` (NEXT_PUBLIC_SUPABASE_URL)
   - `anon public key` (NEXT_PUBLIC_SUPABASE_ANON_KEY)
   - `service_role secret` (SUPABASE_SERVICE_ROLE_KEY)

#### c) Configurar variables de entorno

```bash
cp .env.local.example .env.local
```

Editar `.env.local` y reemplazar los valores:

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 4️⃣ Aplicar migrations (crear tablas)

#### Opción A: Desde Supabase Studio (más fácil)

1. Abrir el dashboard de Supabase
2. Ir a **SQL Editor**
3. Hacer clic en **"New Query"**
4. Copiar el contenido de `supabase/migrations/0001_init.sql`
5. Pegar en el editor y ejecutar (botón ▶️)
6. Esperar a que se complete

#### Opción B: Desde Supabase CLI (avanzado)

```bash
# Instalar CLI
npm install -g supabase

# Conectar al proyecto
supabase link --project-ref tu-project-ref

# Aplicar migrations
supabase db push
```

### 5️⃣ Crear primer usuario

1. Ir a Supabase Dashboard → **Authentication → Users**
2. Hacer clic en **"Add User"**
3. Llenar:
   - **Email:** tu@email.com
   - **Password:** (temporal, cambiar después)
4. Crear usuario

Luego, en **SQL Editor**, ejecutar:

```sql
-- Reemplazar 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' con el UUID del usuario creado
INSERT INTO organizaciones (nombre) VALUES ('Mi Restaurante');

INSERT INTO usuarios (
    id,
    organizacion_id,
    nombre_completo,
    rol_id,
    activo
) VALUES (
    'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
    (SELECT id FROM organizaciones WHERE nombre = 'Mi Restaurante' LIMIT 1),
    'Tu Nombre',
    1,  -- Administrador
    true
);
```

### 6️⃣ Ejecutar el servidor de desarrollo

```bash
npm run dev
```

La app estará en: **http://localhost:3000**

---

## 🔐 Autenticación

### Login inicial

- **Email:** tu@email.com
- **Password:** (la que estableciste)

### Cambiar contraseña

1. Después de loguearse, ir a Settings
2. Cambiar contraseña
3. Confirmar

---

## 📁 Estructura del proyecto

```
GastroCore/
├── app/                          # Next.js App Router
│   ├── (auth)/                   # Rutas de login/signup (públicas)
│   ├── (dashboard)/              # Rutas protegidas con sidebar
│   │   ├── page.tsx              # Dashboard principal
│   │   ├── recetas/              # Gestión de recetas
│   │   ├── insumos/              # Gestión de insumos
│   │   ├── analisis/             # Panel de costos y KPIs
│   │   └── [más...]
│   ├── api/                      # API routes (REST endpoints)
│   ├── layout.tsx                # Layout raíz
│   └── globals.css
├── components/                   # Componentes reutilizables
│   ├── ui/                       # Componentes primitivos
│   ├── InsumoAutocomplete.tsx
│   └── SearchableSelect.tsx
├── lib/
│   ├── api/                      # Funciones de acceso a datos
│   ├── costeo.ts                 # Motor de costeo puro
│   └── [utilidades]
├── supabase/
│   ├── migrations/               # Scripts SQL para la BD
│   │   └── 0001_init.sql         # Esquema inicial
│   └── config.json               # Configuración de Supabase
├── public/                       # Archivos estáticos
├── .env.local.example            # Variables de entorno (template)
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── README.md
```

---

## 🛠️ Desarrollo local

### Scripts disponibles

```bash
# Servidor de desarrollo (hot reload)
npm run dev

# Build para producción
npm run build

# Ejecutar build previamente
npm run start

# Linter/formateo
npm run lint
```

### Editar componentes

Cambios en archivos `.tsx` se reflejan automáticamente en el navegador (hot reload).

---

## 🌐 Desplegar en Vercel

### 1️⃣ Preparar el proyecto

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### 2️⃣ Desplegar

1. Ir a [vercel.com](https://vercel.com)
2. Hacer clic en **"New Project"**
3. Importar repositorio de GitHub
4. En **Environment Variables**, agregar:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
5. Hacer clic en **"Deploy"**

⚠️ **IMPORTANTE:** Nunca commitear `.env.local` con valores reales. Usar solo variables en Vercel.

---

## 🐛 Troubleshooting

### "Cannot find module '@supabase/ssr'"

```bash
npm install
```

### "NEXT_PUBLIC_SUPABASE_URL is not set"

Verificar que `.env.local` existe y tiene los valores correctos:

```bash
cat .env.local  # Ver contenido
```

### "Error: P1001 — Can't reach database server"

- Verificar que la BD de Supabase está activa (dashboard)
- Verificar que el `DATABASE_URL` es correcto

### "401 Unauthorized" en API

Verificar que:
- El usuario existe en `auth.users`
- El usuario tiene fila en tabla `usuarios`
- Las políticas RLS están habilitadas correctamente

---

## 📚 Recursos

- **Documentación de arquitectura:** `arquitectura-erp-recetas.md`
- **Documentación Next.js:** https://nextjs.org/docs
- **Documentación Supabase:** https://supabase.com/docs
- **TailwindCSS:** https://tailwindcss.com/docs

---

## ❓ Preguntas frecuentes

### ¿Puedo usar esta app sin Supabase?

No, Supabase (PostgreSQL + Auth) es fundamental. La BD es el corazón del sistema.

### ¿Cómo agrego más usuarios?

1. Supabase Dashboard → Auth → Add User
2. Insertarlos en tabla `usuarios` con su `organizacion_id` y `rol_id`

### ¿Cómo cambio el tema/colores?

Editar `tailwind.config.ts` y `app/globals.css`.

### ¿Puedo usar esto en producción?

Sí, pero:
- Cambiar todos los datos de ejemplo
- Habilitar HTTPS
- Configurar backups en Supabase
- Revisar políticas de RLS según tus necesidades

---

## 📞 Soporte

¿Problemas? Revisar:
1. Console del navegador (F12 → Console)
2. Logs en Supabase Dashboard
3. Archivo `SETUP.md` (este documento)

---

**¡Listo para cocinar datos! 🍳📊**
