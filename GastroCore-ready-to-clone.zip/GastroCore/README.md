# 🍽️ GastroCore — ERP de Costeo de Recetas para Restaurantes

> **ERP especializado en costeo, recetas e ingredientes.** Reemplaza tu libro de Excel con una plataforma web moderna, escalable y diseñada para restaurantes.

![Version](https://img.shields.io/badge/version-0.1.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-MVP%20Phase-yellow)

---

## ✨ Qué es GastroCore

Un **ERP enfocado completamente en el costeo y gestión de recetas** para restaurantes. Permite:

- 📋 **Gestionar insumos** con conversión automática de unidades (kg ↔ g, L ↔ ml)
- 🍳 **Crear recetas** con ingredientes y cálculo automático de costos
- 📊 **Costeo en tiempo real** — food cost %, precio sugerido, margen
- 🔄 **Subrecetas** — recetas dentro de recetas (módulos de preparación)
- 📈 **Panel de costos** — comparativa de precios, alertas de variación
- 📱 **Interfaz moderna** — diseño inspirado en Linear/Notion
- 🔐 **Multi-tenant ready** — preparado para SaaS multi-restaurante
- 🗄️ **Auditoría completa** — historial de cambios en todas las entidades

---

## 🚀 Quick Start (5 minutos)

### 1. Clonar y setup

```bash
git clone https://github.com/tu-usuario/GastroCore.git
cd GastroCore
npm install
cp .env.local.example .env.local
```

### 2. Crear proyecto en Supabase

1. Ir a [supabase.com](https://supabase.com)
2. Crear nuevo proyecto
3. Copiar credenciales a `.env.local`

### 3. Aplicar migrations

En Supabase Dashboard → SQL Editor:
1. Copiar contenido de `supabase/migrations/0001_init.sql`
2. Ejecutar

### 4. Crear primer usuario

En Supabase Dashboard → Auth → Add User

### 5. Ejecutar

```bash
npm run dev
# Abre http://localhost:3000
```

📖 **Guía completa:** Ver [`SETUP.md`](./SETUP.md)

---

## 🏗️ Stack Tecnológico

| Capa | Tecnología |
|------|------------|
| **Frontend** | Next.js 14 (App Router) + React 18 + TypeScript |
| **Styling** | TailwindCSS + Custom CSS |
| **Backend** | Next.js API Routes + Supabase |
| **Database** | PostgreSQL (Supabase) + RLS |
| **Auth** | Supabase Auth (Magic Link, Password) |
| **Validation** | Zod + React Hook Form |
| **Deployment** | Vercel (recomendado) |

---

## 📁 Estructura del Proyecto

```
GastroCore/
├── app/                          # Next.js App Router
│   ├── (auth)/                   # Rutas de login (públicas)
│   ├── (dashboard)/              # Dashboard y módulos principales
│   │   ├── page.tsx              # Dashboard principal
│   │   ├── recetas/              # CRUD de recetas
│   │   ├── insumos/              # CRUD de insumos
│   │   ├── analisis/             # Panel de costos y KPIs
│   │   └── [más...]
│   └── api/                      # REST API endpoints
├── components/                   # Componentes reutilizables
├── lib/
│   ├── api/                      # Funciones de acceso a datos
│   ├── costeo.ts                 # Motor de costeo puro
│   └── [helpers]
├── supabase/
│   ├── migrations/               # Esquema SQL de la BD
│   └── config.json               # Config de Supabase
├── public/                       # Assets estáticos
├── SETUP.md                      # Guía de setup
├── arquitectura-erp-recetas.md   # Documento de arquitectura
└── package.json
```

---

## 🎯 Funcionalidades (MVP — Fase 1)

### ✅ Implementado

- [x] Autenticación con Supabase
- [x] Dashboard con KPIs
- [x] Catálogos (familias, subfamilias, unidades, proveedores)
- [x] CRUD de insumos con historial de precios
- [x] CRUD de recetas
- [x] Ingredientes con múltiples unidades
- [x] Motor de costeo automático
- [x] Panel de costeo (ticket de cocina)
- [x] Exportar receta a PDF/Excel
- [x] Roles y permisos básicos
- [x] Row Level Security en BD

### 🔄 En progreso

- [ ] Conectar pantallas a datos reales de Supabase
- [ ] Formularios completos (crear/editar)
- [ ] Búsqueda avanzada
- [ ] Importación masiva desde Excel

### 📋 Roadmap (Fases 2+)

- **Fase 2:** Subrecetas, rendimientos, alertas
- **Fase 3:** Trazabilidad, versionado, auditoría
- **Fase 4:** Full-text search, vistas materializadas
- **Fase 5:** Inventarios, compras, POS, IA

---

## 🔐 Seguridad

- ✅ **Row Level Security (RLS)** — aislamiento por organización
- ✅ **Credenciales en variables de entorno** — nunca hardcodeadas
- ✅ **Service Role solo en servidor** — nunca en cliente
- ✅ **HTTPS enforced en producción**
- ✅ **Auditoría de cambios** — event log centralizado

**⚠️ IMPORTANTE:** Nunca commitear `.env.local` con credenciales reales. Usar solo en Vercel Environment Variables.

---

## 📚 Documentación

- **Setup e instalación:** [`SETUP.md`](./SETUP.md)
- **Arquitectura completa:** [`arquitectura-erp-recetas.md`](./arquitectura-erp-recetas.md)
- **Next.js:** https://nextjs.org/docs
- **Supabase:** https://supabase.com/docs
- **TailwindCSS:** https://tailwindcss.com/docs

---

## 🤝 Cómo contribuir

1. Fork el proyecto
2. Crear rama: `git checkout -b feature/mi-feature`
3. Commit: `git commit -m "Add: mi feature"`
4. Push: `git push origin feature/mi-feature`
5. Abrir Pull Request

---

## 📞 Soporte

¿Preguntas o problemas?

1. Revisar [`SETUP.md`](./SETUP.md) — Troubleshooting
2. Revisar logs en Supabase Dashboard
3. Abrir Issue en GitHub

---

## 📄 Licencia

MIT License — Ver [`LICENSE`](./LICENSE)

---

## 🍳 ¿Listo para cocinar datos?

```bash
npm run dev
```

**¡Bienvenido a GastroCore! 🎉**
